from django.apps import AppConfig


class MultiTenantConfig(AppConfig):
    name = 'multi_tenant'
